from django.contrib import admin
from .models import phoneModel

# Register your models here.

admin.site.register(phoneModel)
