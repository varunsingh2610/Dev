from django.apps import AppConfig


class SimpleappConfig(AppConfig):
    name = 'simpleapp'
